# Arcane Beam Resource Pack Sound Slots

Replace these placeholder .ogg files with real Ogg Vorbis sound files, keeping the exact names and paths.

Arcane slots loop while Arcane is active:
- assets/arcanebeam/sounds/abilities/arcane_resourcepack_1.ogg
- assets/arcanebeam/sounds/abilities/arcane_resourcepack_2.ogg

Rail slots play once per Rail cast:
- assets/arcanebeam/sounds/abilities/rail_resourcepack_1.ogg
- assets/arcanebeam/sounds/abilities/rail_resourcepack_2.ogg

Lightning Strike Resourcepack1 slots:
- assets/arcanebeam/sounds/abilities/lightning_strike_arrow_resourcepack_1.ogg
- assets/arcanebeam/sounds/abilities/lightning_resourcepack_1_cast.ogg
- assets/arcanebeam/sounds/abilities/lightning_resourcepack_1_impact.ogg

Lightning Strike Resourcepack2 slots:
- assets/arcanebeam/sounds/abilities/lightning_strike_arrow_resourcepack_2.ogg
- assets/arcanebeam/sounds/abilities/lightning_resourcepack_2_cast.ogg
- assets/arcanebeam/sounds/abilities/lightning_resourcepack_2_impact.ogg

Vault Altar slots play once when the altar beam replacement starts:
- assets/arcanebeam/sounds/abilities/vault_altar_resourcepack_1.ogg
- assets/arcanebeam/sounds/abilities/vault_altar_resourcepack_2.ogg

Storm Arrow slots play when a Storm Arrow strike hits a valid target:
- assets/arcanebeam/sounds/abilities/storm_arrow_resourcepack_1.ogg
- assets/arcanebeam/sounds/abilities/storm_arrow_resourcepack_2.ogg

Lightning Strike arrow sounds play when the target designator projectile is fired. Cast sounds are legacy Seismic Charge shot slots. Impact sounds play when Lightning Strike detonates on a valid target.

No sounds.json is needed for these Arcane Beam slots. Enable this resource pack, then choose Resourcepack1 or Resourcepack2 in the Arcane, Rail, Lightning Strike, Vault Altar, or Storm Arrow sound setting.
